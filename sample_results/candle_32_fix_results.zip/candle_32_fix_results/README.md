# Gramine-TDX results after the fix for candle benchmark (32 threads)

To generate the plots, simply run:
```
cd plots
./plot_generator.sh
```

The plots are placed in a newly created `plots` directory. 

**Notes**: 
- The results for Java are incomplete but the paper results are there for 1 thread - its plots have been removed.
